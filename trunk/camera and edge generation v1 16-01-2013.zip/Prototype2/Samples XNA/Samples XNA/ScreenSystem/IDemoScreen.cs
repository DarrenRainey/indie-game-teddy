﻿namespace FarseerPhysics.SamplesFramework
{
    public interface IDemoScreen
    {
        string GetTitle();
        string GetDetails();
    }
}