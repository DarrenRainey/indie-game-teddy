using FarseerPhysics.Dynamics;
using FarseerPhysics.Factories;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections;
using Prototype2;

namespace Prototype1
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Game
    {
        const int screenWidth = 1280;
        const int screenHeight = 720;
        Vector2 screenCenter = new Vector2(screenWidth / 2, screenHeight / 2);
        
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _batch;
        private KeyboardState _oldKeyState;
        private GamePadState _oldPadState;
        public SpriteFont _font;

        private World _world;

        private Body _circleBody;
        private Body _groundBody;
        private Body playerBody;
        private Body backgroundBody;

        private CompositeCharacter box; 

        private Texture2D _circleSprite;
        private Texture2D _groundSprite;
        private Texture2D background;
        private Texture2D player;
        private Texture2D playerTexture;
        private Texture2D playerJump;
        private Texture2D playerShoot;
        private Texture2D armgun;
        private Texture2D head;

        private Queue bulletQueue;
        private Array tempBulletArray;
        private Texture2D bulletTex;

        //private Vector2 bulletPos;
        //private Boolean isBullet;
        //private Vector2 bulletDirection;       //the XY increment for the bullet
        //private int bulletSpeed = 2;
        //private Vector2 bulletOrigin;

        private SpriteEffects armgunEffects;
        private float armgunAngle;
        private double armgunAngleInDegrees;

        private float headAngle;      
        

        private Animation playerAnimation;
        
        private Activity oldActivity;

        private Texture2D squareTex;        

        private Vector2 playerPos;     

        // Simple camera controls
        private Matrix _view;
        private Vector2 _cameraPosition;
        private Vector2 _screenCenter;
        
        string Text = "BASIC HUD";

        FrameRateCounter fpsCounter;

        private bool showBox = false;
                
        // Farseer expects objects to be scaled to MKS (meters, kilos, seconds)
        // 1 meters equals 100 pixels here
        // (Objects should be scaled to be between 0.1 and 10 meters in size)
        private const float MeterInPixels = 100f;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            _graphics.PreferredBackBufferWidth = screenWidth;
            _graphics.PreferredBackBufferHeight = screenHeight;

            //_graphics.IsFullScreen = true;

            Content.RootDirectory = "Content";

            fpsCounter = new FrameRateCounter();

            _world = new World(new Vector2(0, 30f));
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Initialize camera controls
            _view = Matrix.Identity;
            _cameraPosition = new Vector2(-100f,0f);

            _screenCenter = new Vector2(_graphics.GraphicsDevice.Viewport.Width / 2f,
                                                _graphics.GraphicsDevice.Viewport.Height / 2f);

            _batch = new SpriteBatch(_graphics.GraphicsDevice);
            _font = Content.Load<SpriteFont>("font");

            // Load sprites
            _circleSprite = Content.Load<Texture2D>("circleSprite"); //  96px x 96px => 0.96m x 0.96m
            _groundSprite = Content.Load<Texture2D>("groundSprite"); // 512px x 64px =>   5.12m x 0.64m
            background = Content.Load<Texture2D>("background1"); //  1280px x 720px => 12.8m x 7.2m
            player = Content.Load<Texture2D>("player1"); // 95px x 80px =>   1m x 1.25m
            armgun = Content.Load<Texture2D>("armgun"); // 28px x 67px =>   1m x 1.25m
            head = Content.Load<Texture2D>("head"); // 41px x 37px   
            bulletTex = Content.Load<Texture2D>("bullet");

            squareTex = Content.Load<Texture2D>("square");

            playerJump = Content.Load<Texture2D>("jumping");
            

            //testings
            playerTexture = Content.Load<Texture2D>("run");
            playerAnimation = new Animation();
            playerAnimation.Initialize(playerTexture, Vector2.Zero, 86, 119, 25, 300, Color.White, 1f, true, new Vector2(0, 0));
         
            box = new CompositeCharacter(_world, new Vector2(100f, screenCenter.Y / MeterInPixels), 64, 128, 0.3f, squareTex);
            box.forcePower = 100;

            //init bullet stuff
            //bulletDirection = new Vector2(0, 0);
            bulletQueue = new Queue();
            tempBulletArray = bulletQueue.ToArray();


            /*
            //player
            Vector2 playerPos1 = new Vector2(1f, screenCenter.Y / MeterInPixels);

            // Create the player fixture
            //playerBody = BodyFactory.CreateRectangle(_world, player.Width / MeterInPixels, player.Height / MeterInPixels, 0.7f, playerPos1 + (new Vector2(player.Width / 2, player.Height / 2) / MeterInPixels));
            playerBody = BodyFactory.CreateCircle(_world, player.Height / (2f * MeterInPixels), 1f, playerPos1 + (new Vector2(player.Width / 2, player.Height / 2) / MeterInPixels));
            playerBody.BodyType = BodyType.Dynamic;
            playerBody.Restitution = 0.0f;
            playerBody.Friction = 0.1f; 


            //Circle 
            Vector2 circlePosition = new Vector2((1f + (_groundSprite.Width / MeterInPixels) / 2) - ((_circleSprite.Width / MeterInPixels) / 2), 0f) + (new Vector2(_circleSprite.Width / MeterInPixels, _circleSprite.Height / MeterInPixels) / 2);

            // Create the circle fixture
            _circleBody = BodyFactory.CreateCircle(_world, 96f / (2f * MeterInPixels), 1f, circlePosition);
            _circleBody.BodyType = BodyType.Dynamic;
            _circleBody.Restitution = 0.3f;
            _circleBody.Friction = 0.5f;

            //Ground
            Vector2 groundPosition = new Vector2(1f, 6.5f) + (new Vector2(_groundSprite.Width / MeterInPixels, _groundSprite.Height / MeterInPixels) / 2);

            // Create the ground fixture
            _groundBody = BodyFactory.CreateRectangle(_world, 512f / MeterInPixels, 64f / MeterInPixels, 1f, groundPosition);
            _groundBody.IsStatic = true;
            _groundBody.Restitution = 0.3f;
            _groundBody.Friction = 0.5f;
            
            */

            //edge

            // Create the ground fixture
            Body edgeBody = BodyFactory.CreateEdge(_world, new Vector2(0f, 3f), new Vector2(0.25f, 3f));
            edgeBody.IsStatic = true;
            edgeBody.Restitution = 0.1f;
            edgeBody.Friction = 0.7f;

            FixtureFactory.AttachEdge(new Vector2(0.25f, 3f), new Vector2(0.25f, 6f), edgeBody);
            FixtureFactory.AttachEdge(new Vector2(0.25f, 6f), new Vector2(5f, 6f), edgeBody);
            FixtureFactory.AttachEdge(new Vector2(5f, 6f), new Vector2(5f, 7.2f), edgeBody);

            FixtureFactory.AttachEdge(new Vector2(7f, 7.2f), new Vector2(7f, 5f), edgeBody);
            FixtureFactory.AttachEdge(new Vector2(7f, 5f), new Vector2(12.8f, 5f), edgeBody);

            FixtureFactory.AttachEdge(new Vector2(12.8f, 3f), new Vector2(10f, 3f), edgeBody);
            FixtureFactory.AttachEdge(new Vector2(10f, 3f), new Vector2(10f, 2.5f), edgeBody);
            FixtureFactory.AttachEdge(new Vector2(10f, 2.5f), new Vector2(12.8f, 2.5f), edgeBody);

            FixtureFactory.AttachEdge(new Vector2(4f, 1.5f), new Vector2(8f, 1.5f), edgeBody);
            FixtureFactory.AttachEdge(new Vector2(8f, 1.5f), new Vector2(8f, 2f), edgeBody);
            FixtureFactory.AttachEdge(new Vector2(8f, 2f), new Vector2(4f, 2f), edgeBody);
            FixtureFactory.AttachEdge(new Vector2(4f, 2f), new Vector2(4f, 1.5f), edgeBody);                
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {            
            HandleGamePad();
            HandleKeyboard();

            fpsCounter.Update(gameTime);

            if (box.activity == Activity.Idle && oldActivity != Activity.Idle)
            {
                Vector2 temp = playerAnimation.Position;
                playerAnimation.Initialize(player, temp, 100, 123, 1, 0, Color.White, 1f, true, new Vector2(0, 0));                
            }
            else if (box.activity == Activity.Jumping && oldActivity != Activity.Jumping)
            {
                Vector2 temp = playerAnimation.Position;
                playerAnimation.Initialize(playerJump, temp, 120, 125, 23, 10, Color.White, 1f, false, new Vector2(0, 0));
            }
            else if (box.activity == Activity.Running && oldActivity != Activity.Running)
            {
                Vector2 temp = playerAnimation.Position;
                playerAnimation.Initialize(playerTexture, temp, 86, 121, 26, 30, Color.White, 1f, true, new Vector2(0, 0));
            }            

            oldActivity = box.activity;              

            box.Update(gameTime);
            
            playerAnimation.Update(gameTime);

            //We update the world
            _world.Step((float)gameTime.ElapsedGameTime.TotalMilliseconds * 0.001f);

            base.Update(gameTime);
        }

        private void HandleGamePad()
        {
            GamePadState padState = GamePad.GetState(PlayerIndex.One, GamePadDeadZone.Circular);

            //bullet stuff
            if (bulletQueue.Count > 0)
            {
                tempBulletArray = bulletQueue.ToArray();
                bulletQueue.Clear();                                  //convert to array, clear the queue and fill it up after changes

                for (int i = 0; i < tempBulletArray.Length; i++)
                {
                    ((Bullet)tempBulletArray.GetValue(i)).CurrentPos += ((Bullet)tempBulletArray.GetValue(i)).DirectionIncrement;

                    bulletQueue.Enqueue((Bullet)tempBulletArray.GetValue(i));
                }

                if (((Bullet)bulletQueue.Peek()).isDead())        //remove dead bullets from the queue
                {
                    bulletQueue.Dequeue();
                }
            }

            if (padState.IsConnected)
            {
                if (padState.Buttons.Back == ButtonState.Pressed)
                    Exit();
                                

                if (padState.Buttons.B == ButtonState.Pressed && _oldPadState.Buttons.B == ButtonState.Released)
                {
                    if (showBox == true)
                    {
                        showBox = false;
                    }
                    else
                    {
                        showBox = true;
                    }
                }

                if (padState.Triggers.Right > 0.5 && _oldPadState.Triggers.Right < 0.5)
                {
                    Bullet bullet = new Bullet();
                    bullet.Texture = bulletTex;                    

                    if (padState.ThumbSticks.Right.X > 0.50 || padState.ThumbSticks.Right.X < -0.50 || padState.ThumbSticks.Right.Y > 0.50 || padState.ThumbSticks.Right.Y < -0.50)
                    {
                        bullet.DirectionIncrement = (padState.ThumbSticks.Right * new Vector2(1, -1));
                    }
                    else
                    {
                        if (armgunEffects == SpriteEffects.None)
                        {
                            bullet.DirectionIncrement = new Vector2(1, 0);
                        }
                        else if (armgunEffects == SpriteEffects.FlipHorizontally)
                        {
                            bullet.DirectionIncrement = new Vector2(-1, 0);
                        }
                    }

                    Vector2 perpToDirection;

                    //arm pivot point + direction multiplyed by guess number to bring the bullet origin to the tip of the pistol. 
                    //also moved a few pixels 90 degrees perpendicular to direction to match the tip of the gun  
                    if (armgunEffects == SpriteEffects.None)
                    {
                        perpToDirection = new Vector2(bullet.DirectionIncrement.Y, bullet.DirectionIncrement.X * -1) * 12;

                        bullet.Origin = new Vector2(box.Position.X + 10, box.Position.Y - 20) + (bullet.DirectionIncrement * 55) + perpToDirection;
                    }
                    else if (armgunEffects == SpriteEffects.FlipHorizontally)
                    {
                        perpToDirection = new Vector2(bullet.DirectionIncrement.Y * -1, bullet.DirectionIncrement.X) * 12;

                        bullet.Origin = new Vector2(box.Position.X - 20, box.Position.Y - 20) + (bullet.DirectionIncrement * 55) + perpToDirection;
                    }

                    bullet.CurrentPos = bullet.Origin;
                    bullet.DirectionIncrement *= bullet.Speed; 

                    bulletQueue.Enqueue(bullet);    //add the bullet to the queue of bullets
                }

                if (padState.ThumbSticks.Right.X > 0.50 || padState.ThumbSticks.Right.X < -0.50 || padState.ThumbSticks.Right.Y > 0.50 || padState.ThumbSticks.Right.Y < -0.50)
                {
                    armgunAngle = (float)Math.Atan2(padState.ThumbSticks.Right.Y, padState.ThumbSticks.Right.X) * -1;

                    armgunAngleInDegrees = (armgunAngle * 180) / Math.PI;

                    if (armgunAngleInDegrees > 90 || armgunAngleInDegrees < -90)
                    {
                        playerAnimation.myEffect = SpriteEffects.FlipHorizontally;
                        armgunEffects = SpriteEffects.FlipHorizontally;
                    }
                    else
                    {
                        playerAnimation.myEffect = SpriteEffects.None;
                        armgunEffects = SpriteEffects.None;
                    }
                }
                else
                {                   
                    armgunAngle = 0.0f;
                    headAngle = 0.0f;                   
                }

                _cameraPosition.X -= padState.ThumbSticks.Right.X;
                _cameraPosition.Y += padState.ThumbSticks.Right.Y;

                _view = Matrix.CreateTranslation(new Vector3(_cameraPosition - _screenCenter, 0f)) * Matrix.CreateTranslation(new Vector3(_screenCenter, 0f));

                _oldPadState = padState;
            }
        }

        private void HandleKeyboard()
        {
            KeyboardState state = Keyboard.GetState();

            
                // Move camera
                if (state.IsKeyDown(Keys.A))
                    _cameraPosition.X += 1.5f;

                if (state.IsKeyDown(Keys.D))
                    _cameraPosition.X -= 1.5f;

                if (state.IsKeyDown(Keys.W))
                    _cameraPosition.Y += 1.5f;

                if (state.IsKeyDown(Keys.S))
                    _cameraPosition.Y -= 1.5f;

                _view = Matrix.CreateTranslation(new Vector3(_cameraPosition - _screenCenter, 0f)) *
                        Matrix.CreateTranslation(new Vector3(_screenCenter, 0f));
            
            
            /*if (state.IsKeyDown(Keys.Left))
            {
                playerAnimation.myEffect = SpriteEffects.FlipHorizontally;
                shootAnimation.myEffect = SpriteEffects.FlipHorizontally;
                armgunEffects = SpriteEffects.FlipHorizontally;
            }
            else if (state.IsKeyDown(Keys.Right))
            {
                playerAnimation.myEffect = SpriteEffects.None;
                shootAnimation.myEffect = SpriteEffects.None;
                armgunEffects = SpriteEffects.None;
            }*/

            if (state.IsKeyDown(Keys.B) && _oldKeyState.IsKeyDown(Keys.B) == false)
            {
                if (showBox == true)
                {
                    showBox = false;
                }
                else
                {
                    showBox = true;
                }
            }
            
            if (state.IsKeyDown(Keys.Escape))
                Exit();

            _oldKeyState = state;
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            fpsCounter.frameCounter++;

            /* Circle position and rotation */
            // Convert physics position (meters) to screen coordinates (pixels)
            //Vector2 circlePos = _circleBody.Position * MeterInPixels;
            //float circleRotation = _circleBody.Rotation;                       

            /* Ground position and origin */
            //Vector2 groundPos = _groundBody.Position * MeterInPixels;
            //Vector2 groundOrigin = new Vector2(_groundSprite.Width / 2f, _groundSprite.Height / 2f);

            // Align sprite center to body position
            //Vector2 circleOrigin = new Vector2(_circleSprite.Width / 2f, _circleSprite.Height / 2f);

            //_batch.Begin(SpriteSortMode.Deferred, null, null, null, null, null, _view);

            //_batch.Draw(background, new Vector2(0, 0), Color.White);

            //player pos calc
            //playerPos = (playerBody.Position * MeterInPixels) - new Vector2(player.Width / 2, player.Height / 2);

            //Console.WriteLine("PLAYER BODY POS: x=" + playerBody.Position.X + "  y: " + playerBody.Position.Y);

            //draw player
            //_batch.Draw(player, playerPos, Color.White);
            
            //Draw circle
            //_batch.Draw(_circleSprite, circlePos, null, Color.White, circleRotation, circleOrigin, 1f, SpriteEffects.None, 0f);

            //Draw ground
            //_batch.Draw(_groundSprite, groundPos, null, Color.White, 0f, groundOrigin, 1f, SpriteEffects.None, 0f);

            //_batch.End();

            _batch.Begin();

            _batch.Draw(background, new Vector2(0, 0), Color.White);
            
            Text = "FPS: " + fpsCounter.frameRate + "    player effect: " + playerAnimation.myEffect;

            // Display instructions
            _batch.DrawString(_font, Text, new Vector2(34f, 34f), Color.Black);
            _batch.DrawString(_font, Text, new Vector2(32f, 32f), Color.White);
                       
            _batch.End();

            _batch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend);

            if (showBox == true)
            {
                box.Draw(_batch);
            }

            int armgunXOffset = 0;            
            Vector2 armgunOrigin = Vector2.Zero;            

            if (armgunEffects == SpriteEffects.None)
            {
                armgunXOffset = 17;
                armgunOrigin = new Vector2(6, 17);                
            }
            else if (armgunEffects == SpriteEffects.FlipHorizontally)
            {
                armgunXOffset = -18;
                armgunOrigin = new Vector2(60, 17);                

                GamePadState padState = GamePad.GetState(PlayerIndex.One, GamePadDeadZone.Circular);

                if(padState.ThumbSticks.Right.X > 0.50 || padState.ThumbSticks.Right.X < -0.50 || padState.ThumbSticks.Right.Y > 0.50 || padState.ThumbSticks.Right.Y < -0.50)
                {
                    if (armgunAngleInDegrees < -180 || armgunAngleInDegrees > -90)
                    {
                        armgunAngleInDegrees = -180 + armgunAngleInDegrees;

                        armgunAngle = (float)(armgunAngleInDegrees * Math.PI) / 180;
                    }
                    else if (armgunAngleInDegrees < 180 || armgunAngleInDegrees > 90)
                    {
                        armgunAngleInDegrees = (armgunAngleInDegrees + 180);                       

                        armgunAngle = (float)(armgunAngleInDegrees * Math.PI) / 180;                        
                    }                    
                }
            }

            headAngle = armgunAngle / 3;             //head rotates with analog stick but 3 times slower

            //Console.WriteLine("drawangle: " + armgunAngle * 180 / Math.PI);

            _batch.Draw(armgun, new Rectangle((int)box.Position.X + armgunXOffset, (int)box.Position.Y - 15, armgun.Width, armgun.Height), new Rectangle(0, 0, armgun.Width, armgun.Height), Color.White, armgunAngle, armgunOrigin, armgunEffects, 0.0f);


            //testings 
            box.Update(gameTime);
            playerAnimation.Position = box.Position;  
            playerAnimation.Update(gameTime);
            playerAnimation.Draw(_batch);



            _batch.Draw(head, new Rectangle((int)playerAnimation.Position.X + 0, (int)playerAnimation.Position.Y - 35, head.Width, head.Height), new Rectangle(0, 0, head.Width, head.Height), Color.White, headAngle, new Vector2(20, 18), armgunEffects, 0.0f);



            for (int i = 0; i < tempBulletArray.Length; i++)
            {
                _batch.Draw(((Bullet)tempBulletArray.GetValue(i)).Texture, ((Bullet)tempBulletArray.GetValue(i)).CurrentPos, Color.White);
            }

            /*if (bullet != null)
            {
                _batch.Draw(bullet.Texture, bullet.CurrentPos, Color.White);
            }*/



            

            _batch.DrawString(_font, box.activity.ToString(), new Vector2(90, 105), Color.Red);
            _batch.End();

            base.Draw(gameTime);
        }

        private float DegreeToRadian(float angle)
        {
            float PI = (float)Math.PI;

            return PI * angle / 180.0f;
        }
    }
}